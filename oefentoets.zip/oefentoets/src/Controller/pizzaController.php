<?php

namespace App\Controller;

use App\Entity\Bestelling;
use App\Entity\Bestelregel;
use App\Entity\Category;
use App\Entity\Klant;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class pizzaController extends AbstractController
{
    /**
     * @Route ("/categories")
     */

    public function home(EntityManagerInterface $em) {
    $cats = $em->getRepository(Category::class)->findAll();
    $klantNaam = $em->getRepository(Klant::class)->findAll();
    $datum = $em->getRepository(Bestelling::class)->findAll();
    $bestelling = $em->getRepository(Bestelregel::class)->findAll();
    return $this->render('home.html.twig',[
        'cats'=>$cats,
        'klantNaam'=>$klantNaam,
        'datum'=>$datum,
        'bestelling'=>$bestelling
    ]);

    }
}