<?php

namespace App\Entity;

use App\Repository\BestellingRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=BestellingRepository::class)
 */
class Bestelling
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="date")
     */
    private $datum;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $status;

    /**
     * @ORM\ManyToOne(targetEntity=Klant::class, inversedBy="bestelling")
     */
    private $klant;

    /**
     * @ORM\OneToMany(targetEntity=Bestelregel::class, mappedBy="bestelling")
     */
    private $bestelregel;

    public function __construct()
    {
        $this->bestelregel = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDatum(): ?\DateTimeInterface
    {
        return $this->datum;
    }

    public function setDatum(\DateTimeInterface $datum): self
    {
        $this->datum = $datum;

        return $this;
    }

    public function getStatus(): ?string
    {
        return $this->status;
    }

    public function setStatus(string $status): self
    {
        $this->status = $status;

        return $this;
    }

    public function getKlant(): ?Klant
    {
        return $this->klant;
    }

    public function setKlant(?Klant $klant): self
    {
        $this->klant = $klant;

        return $this;
    }

    /**
     * @return Collection<int, bestelregel>
     */
    public function getBestelregel(): Collection
    {
        return $this->bestelregel;
    }

    public function addBestelregel(bestelregel $bestelregel): self
    {
        if (!$this->bestelregel->contains($bestelregel)) {
            $this->bestelregel[] = $bestelregel;
            $bestelregel->setBestelling($this);
        }

        return $this;
    }

    public function removeBestelregel(bestelregel $bestelregel): self
    {
        if ($this->bestelregel->removeElement($bestelregel)) {
            // set the owning side to null (unless already changed)
            if ($bestelregel->getBestelling() === $this) {
                $bestelregel->setBestelling(null);
            }
        }

        return $this;
    }
}
